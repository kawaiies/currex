// Mobile menu toggle
document.addEventListener('DOMContentLoaded', function() {
  var menuBtn = document.getElementById('mobileMenuBtn');
  if (menuBtn) {
    menuBtn.addEventListener('click', function() {
      var navList = document.querySelector('.nav-list');
      if (navList) { navList.classList.toggle('open'); }
    });
  }
});
